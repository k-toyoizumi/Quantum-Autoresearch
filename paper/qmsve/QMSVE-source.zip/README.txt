English QMSVE technical-report source draft. This is not an arXiv submission.

Build the PDF from this directory with:
  xelatex -interaction=nonstopmode -halt-on-error main.tex
  xelatex -interaction=nonstopmode -halt-on-error main.tex

The Lean appendix source is lean/QMSVE.lean. Its standalone project files are in lean/.
The deterministic matrix-level experiment and saved output are in experiments/ and results/.
The manuscript does not claim circuit synthesis, end-to-end quantum advantage, or novelty.
