English QMSVE technical-report source draft. This is not an arXiv submission.

Build the PDF from this directory with:
  xelatex -interaction=nonstopmode -halt-on-error main.tex
  xelatex -interaction=nonstopmode -halt-on-error main.tex

The Lean appendix source is lean/QMSVE.lean. Its standalone project files are in lean/.
The deterministic matrix-level and gap-free envelope experiments are in experiments/ and results/.
Create figures/ if absent before running the scripts, and install requirements-numerics.txt.
The combined sharp analysis is a modest contribution candidate with unresolved priority.
New sharp-envelope/rate/perturbation proofs are hand-derived, not Lean-verified.
The manuscript does not claim circuit synthesis or end-to-end quantum advantage.
