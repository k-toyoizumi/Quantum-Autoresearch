Reproducibility files for Prior-Robust QSVT Filter Selection.
Author metadata is intentionally omitted from this review copy.
No submission has been performed.

From this ancillary directory, install requirements.txt in an isolated Python
environment and run:
  python experiments/check_selection_certificates.py
  python experiments/filter_selection.py
  python experiments/selection_qsp.py
  python experiments/selection_matrix_audit.py
  python experiments/selection_figures.py
The scripts use the data paths relative to this directory. No Git checkout
is needed. Regeneration overwrites corresponding data and figures.
For a short design run:
  python experiments/filter_selection.py --pilot --output work/pilot.json
The plot script writes its generated TeX table under paper/filter-selection/;
copy that table to the article source if regenerating the manuscript.
From lean/, use the pinned toolchain:
  lake build Selection
  lake env lean SelectionAudit.lean
Only the five documented scalar lemmas were checked in Lean.
Read claim-evidence.md and novelty-review.md for the restricted claim scope.
