Prior-Robust QSVT Filter Selection: Gap-Free Bias and Finite-Budget Risk

English entry point: main.tex. Japanese companion: main-ja.tex.
Author information is intentionally omitted in this review copy.
No upload/submission has been performed.

Compile (XeLaTeX with AMS/fontspec/hyperref/geometry packages):
  xelatex -interaction=nonstopmode -halt-on-error main.tex
  xelatex -interaction=nonstopmode -halt-on-error main.tex
  xelatex -interaction=nonstopmode -halt-on-error main-ja.tex
  xelatex -interaction=nonstopmode -halt-on-error main-ja.tex
Tectonic can also compile both entry points; some static builds require
the matching ICU data for Japanese line breaking.

From this directory, install requirements.txt in an isolated Python environment.
Full numerical reproduction:
  python experiments/filter_selection.py
  python experiments/selection_qsp.py
  python experiments/selection_matrix_audit.py
  python experiments/selection_figures.py
  python experiments/check_selection_certificates.py
Application and finite-sampling extension (ideal circuits):
  python experiments/selection_ising_application.py
  python experiments/selection_ising_figures.py
  python experiments/check_finite_sampling.py
  python experiments/selection_finite_budget.py
  python experiments/selection_finite_precision.py
  python experiments/finite_sampling_figures.py
The full design run is finite (10 cases), usually a few minutes.
The pilot flag runs two nontrivial cases; use a separate output file:
  python experiments/filter_selection.py --pilot --output work/pilot.json
Regeneration overwrites the corresponding results and figures.
Exact certificate decisions use rational/integer arithmetic. LP and phase
solver candidates use floating point and may vary across platforms.
No Git repository is needed. SOURCE-MANIFEST.json identifies the supplied files.

Lean reproduction from lean/ with the pinned Lean toolchain:
  lake build Selection
  lake env lean SelectionAudit.lean
  lake build FiniteSampling
  lake env lean FiniteSamplingAudit.lean
Five selection and four finite-sampling scalar lemmas were checked locally.
The statistical/support-reduction theorem is a hand proof, not fully formalized.
No successful remote CI run is claimed. Read claim-evidence.md and novelty-review.md.

The query guarantees are for the specified real endpoint-nulling polynomial,
restart, ideal signal, and finite bias-allocation model; not a general
quantum advantage or hardware resource estimate.
